Para ejecutar el programa basta con ingresar por terminal
El algoritmo se encuentra definido para trabajar con ejemplares entre 5 y 100 elementos,
la conformación del ejemplar de la gráfica es pseudoaleatorio, el ejemplar se muestra
en la parte superior seguida por la cubierta generada, así como el tiempo y la complejidad
en tiempo aproximados.

```
$python Covering_Set_Problem.py
```
o
```
$python3 Covering_Set_Problem.py
```
