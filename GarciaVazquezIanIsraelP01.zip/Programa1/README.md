#Programa 1
Para esta práctica se encuentran 2 programas,
para el programa Alcanzabilidad.py basta con ejecutar
```
python Alcanzabilidad.py
```
Mientras que para el programa 3SAT, bastará con
```
python 3SAT.py
```
